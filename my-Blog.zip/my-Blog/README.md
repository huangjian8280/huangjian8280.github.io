### Usage

This is a project template for [vue-cli](https://github.com/vuejs/vue-cli).

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8081
npm run dev

# build for production with minification
npm run build

```

### Browser Support

Modern browsers and Internet Explorer 10+.

### snapshots
![image](https://raw.githubusercontent.com/taylorchen709/markdown-images/master/vueadmin/login.png)
![image](https://raw.githubusercontent.com/taylorchen709/markdown-images/master/vueadmin/main.png)
![image](https://raw.githubusercontent.com/taylorchen709/markdown-images/master/vueadmin/edit.jpg)

### License
[MIT](http://opensource.org/licenses/MIT)
